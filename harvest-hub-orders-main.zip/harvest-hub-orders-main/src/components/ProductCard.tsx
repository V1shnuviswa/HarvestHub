
import React from 'react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export interface Product {
  id: number;
  name: string;
  price: number;
  imageUrl: string;
  description?: string;
  unit?: string;
}

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const navigate = useNavigate();
  
  const handleOrder = () => {
    // Navigate to order page with product id
    navigate(`/order?product=${product.id}`);
  };
  
  return (
    <Card className="overflow-hidden transition-shadow hover:shadow-md">
      <div className="h-48 overflow-hidden">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="pt-4">
        <div className="flex justify-between items-center">
          <h3 className="font-semibold text-lg">{product.name}</h3>
          <span className="font-bold text-primary">₹{product.price.toFixed(2)}/{product.unit || 'kg'}</span>
        </div>
        {product.description && (
          <p className="text-muted-foreground text-sm mt-2">{product.description}</p>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={handleOrder} className="w-full">
          <ShoppingCart className="mr-2 h-4 w-4" /> Order Now
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
