
import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from "sonner";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requireAdmin = false 
}) => {
  const { isAuthenticated, isAdmin, loading } = useAuth();
  const location = useLocation();
  
  useEffect(() => {
    // Show message only when loaded to avoid flashing messages
    if (!loading) {
      if (!isAuthenticated) {
        toast.error("Please log in to access this page");
      } else if (requireAdmin && !isAdmin) {
        toast.error("Admin access required");
      }
    }
  }, [isAuthenticated, isAdmin, loading, requireAdmin]);

  // Show loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Not authenticated at all
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Authenticated but not admin (when admin access is required)
  if (requireAdmin && !isAdmin) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  // Authenticated and has proper permissions
  return <>{children}</>;
};

export default ProtectedRoute;
