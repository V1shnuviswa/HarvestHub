
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';
import { toast } from "sonner";

export type UserRole = 'user' | 'admin';

export interface UserWithRole extends Omit<User, 'role'> {
  role?: UserRole;
  name?: string;
}

interface AuthContextType {
  currentUser: UserWithRole | null;
  session: Session | null;
  login: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: boolean;
  isAuthenticated: boolean;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Admin credentials - hardcoded for easier reference
const ADMIN_EMAIL = 'hawkydevill@gmail.com';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserWithRole | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Set up auth state change listener FIRST to prevent missing events
        const { data } = supabase.auth.onAuthStateChange(
          (event, session) => {
            console.log("Auth state change detected, event:", event, "email:", session?.user?.email);
            setSession(session);
            if (session?.user) {
              console.log("Auth state change detected, user:", session.user.email);
              const userWithRole: UserWithRole = {
                ...session.user,
                name: session.user.user_metadata?.name || '',
                role: session.user.email === ADMIN_EMAIL ? 'admin' : 'user'
              };
              console.log("User role:", userWithRole.role);
              setCurrentUser(userWithRole);
            } else {
              setCurrentUser(null);
            }
            setLoading(false);
          }
        );
        
        // THEN check for existing session
        const { data: { session: existingSession } } = await supabase.auth.getSession();
        setSession(existingSession);
        if (existingSession?.user) {
          console.log("Existing session found, user:", existingSession.user.email);
          const userWithRole: UserWithRole = {
            ...existingSession.user,
            name: existingSession.user.user_metadata?.name || '',
            role: existingSession.user.email === ADMIN_EMAIL ? 'admin' : 'user'
          };
          console.log("User role for existing session:", userWithRole.role, "Email:", userWithRole.email);
          setCurrentUser(userWithRole);
        } else {
          setCurrentUser(null);
        }
        setLoading(false);
        
        return () => {
          data.subscription.unsubscribe();
        };
      } catch (error) {
        console.error("Error initializing auth:", error);
        setLoading(false);
        return () => {};
      }
    };
    
    initializeAuth();
  }, []);

  const isAdmin = currentUser?.email === ADMIN_EMAIL;
  const isAuthenticated = !!currentUser;

  console.log("Auth context state - isAdmin:", isAdmin, "Email:", currentUser?.email);

  const login = async (email: string, password: string) => {
    try {
      // Special handling for admin login
      if (email === ADMIN_EMAIL) {
        console.log("Attempting admin login");
        // First try direct login
        const { data, error: loginError } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        
        // If login fails, try to create admin account first
        if (loginError) {
          console.log('Admin login failed, attempting to create admin account:', loginError.message);
          
          // Try to create the admin account
          const { error: signUpError } = await supabase.auth.signUp({
            email,
            password,
            options: {
              data: { name: 'Admin' },
              emailRedirectTo: window.location.origin
            }
          });
          
          if (signUpError) {
            throw signUpError;
          }
          
          // Try login again after creating account
          const { error: secondLoginError } = await supabase.auth.signInWithPassword({
            email,
            password
          });
          
          if (secondLoginError) throw secondLoginError;
        }
        
        console.log("Admin login successful");
        toast.success('Logged in successfully as admin');
      } else {
        // Regular user login
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        
        if (error) throw error;
        
        toast.success('Logged in successfully');
      }
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error(error.message || 'Failed to login');
      throw error;
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    try {
      // Special handling for admin account - no email verification
      if (email === ADMIN_EMAIL) {
        // First try to create the account
        const { error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { name },
            emailRedirectTo: window.location.origin
          }
        });
        
        if (signUpError && signUpError.message !== "User already registered") {
          throw signUpError;
        }
        
        // Then directly sign in
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password
        });
        
        if (signInError) throw signInError;
        
        toast.success('Admin account logged in successfully');
        return;
      } 
      
      // Regular user signup with email verification
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { name },
          emailRedirectTo: window.location.origin
        }
      });
      
      if (error) throw error;
      toast.success('Account created successfully. Please check your email for verification.');
      
    } catch (error: any) {
      console.error('Signup error:', error);
      toast.error(error.message || 'Failed to create account');
      throw error;
    }
  };

  const logout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      toast.success('Logged out successfully');
    } catch (error: any) {
      console.error('Logout error:', error);
      toast.error(error.message || 'Failed to logout');
    }
  };

  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      session,
      login, 
      signUp,
      logout, 
      isAdmin,
      isAuthenticated,
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
