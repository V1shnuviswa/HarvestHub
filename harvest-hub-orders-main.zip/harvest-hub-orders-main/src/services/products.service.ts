import { supabase, getAuthToken } from "@/integrations/supabase/client";
import { Product } from "@/types/api.types";
import { toast } from "sonner";

export const getProducts = async (): Promise<Product[]> => {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*');
    
    if (error) throw error;
    
    if (!data || data.length === 0) {
      await seedProducts();
      
      const { data: seededData, error: seededError } = await supabase
        .from('products')
        .select('*');
      
      if (seededError) throw seededError;
      
      return transformProducts(seededData || []);
    }
    
    return transformProducts(data);
  } catch (error) {
    console.error('Error fetching products:', error);
    toast.error('Failed to fetch products');
    return [];
  }
};

export const getProductById = async (id: number): Promise<Product | undefined> => {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    
    return transformProduct(data);
  } catch (error) {
    console.error('Error fetching product:', error);
    toast.error('Failed to fetch product details');
    return undefined;
  }
};

export const addProduct = async (product: Omit<Product, 'id'>): Promise<Product> => {
  try {
    const token = await getAuthToken();
    if (!token) {
      throw new Error("Not authenticated");
    }
    
    const { data, error } = await supabase
      .from('products')
      .insert({
        name: product.name,
        price: product.price,
        image_url: product.imageUrl,
        description: product.description,
        unit: product.unit
      })
      .select()
      .single();
    
    if (error) {
      throw new Error(`Failed to add product: ${error.message}`);
    }
    
    return transformProduct(data);
  } catch (error) {
    console.error('Error adding product:', error);
    toast.error('Failed to add product. Please make sure you have admin privileges.');
    throw error;
  }
};

export const updateProduct = async (id: number, updates: Partial<Product>): Promise<Product> => {
  try {
    const updateData = {
      ...(updates.name && { name: updates.name }),
      ...(updates.price && { price: updates.price }),
      ...(updates.imageUrl && { image_url: updates.imageUrl }),
      ...(updates.description && { description: updates.description }),
      ...(updates.unit && { unit: updates.unit })
    };
    
    const token = await getAuthToken();
    if (!token) {
      throw new Error("Not authenticated");
    }

    const { data, error } = await supabase
      .from('products')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      throw new Error(`Failed to update product: ${error.message}`);
    }
    
    return transformProduct(data);
  } catch (error) {
    console.error('Error updating product:', error);
    toast.error('Failed to update product');
    throw error;
  }
};

export const deleteProduct = async (id: number): Promise<void> => {
  try {
    const token = await getAuthToken();
    if (!token) {
      throw new Error("Not authenticated");
    }

    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);
    
    if (error) {
      throw new Error(`Failed to delete product: ${error.message}`);
    }
    
    toast.success('Product deleted successfully');
  } catch (error) {
    console.error('Error deleting product:', error);
    toast.error('Failed to delete product');
    throw error;
  }
};

// Helper function to transform database product to API product
const transformProduct = (data: any): Product => ({
  id: data.id,
  name: data.name,
  price: data.price,
  imageUrl: data.image_url,
  description: data.description,
  unit: data.unit
});

const transformProducts = (data: any[]): Product[] => 
  data.map(transformProduct);

// Seed products function
export const seedProducts = async (): Promise<void> => {
  try {
    console.log("Attempting to seed products");
    
    // Check if products exist
    const { data, error } = await supabase
      .from('products')
      .select('id')
      .limit(1);
    
    if (error) throw error;
    
    // If products exist, do nothing
    if (data && data.length > 0) {
      console.log("Products already exist, no need to seed");
      return;
    }
    
    // Seed products with supabase client
    const products = [
      {
        name: 'Organic Carrots',
        price: 2.99,
        image_url: 'https://images.unsplash.com/photo-1447175008436-054170c2e979?q=80&w=500',
        description: 'Fresh, locally-grown organic carrots.',
        unit: 'kg'
      },
      {
        name: 'Red Apples',
        price: 3.49,
        image_url: 'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?q=80&w=500',
        description: 'Sweet and crisp red apples.',
        unit: 'kg'
      },
      {
        name: 'Fresh Broccoli',
        price: 1.99,
        image_url: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?q=80&w=500',
        description: 'Farm-fresh green broccoli.',
        unit: 'kg'
      },
      {
        name: 'Organic Strawberries',
        price: 4.99,
        image_url: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?q=80&w=500',
        description: 'Sweet, juicy organic strawberries.',
        unit: 'box'
      },
      {
        name: 'Vine Tomatoes',
        price: 2.49,
        image_url: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfad?q=80&w=500',
        description: 'Ripe, vine-grown tomatoes.',
        unit: 'kg'
      },
      {
        name: 'Iceberg Lettuce',
        price: 1.79,
        image_url: 'https://images.unsplash.com/photo-1556801712-76c8eb07bbc9?q=80&w=500',
        description: 'Crisp iceberg lettuce.',
        unit: 'head'
      },
      {
        name: 'Russet Potatoes',
        price: 2.29,
        image_url: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?q=80&w=500',
        description: 'Premium russet potatoes.',
        unit: 'kg'
      },
      {
        name: 'Yellow Onions',
        price: 1.89,
        image_url: 'https://images.unsplash.com/photo-1580201092675-a0a6a6cafbb1?q=80&w=500',
        description: 'Fresh yellow onions.',
        unit: 'kg'
      },
      {
        name: 'Baby Spinach',
        price: 2.99,
        image_url: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?q=80&w=500',
        description: 'Tender baby spinach leaves.',
        unit: 'bunch'
      },
      {
        name: 'Mixed Bell Peppers',
        price: 3.49,
        image_url: 'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?q=80&w=500',
        description: 'Colorful mix of bell peppers.',
        unit: 'kg'
      },
      {
        name: 'English Cucumber',
        price: 1.99,
        image_url: 'https://images.unsplash.com/photo-1449300079323-02e209d9d3a6?q=80&w=500',
        description: 'Long English cucumbers.',
        unit: 'piece'
      },
      {
        name: 'Organic Bananas',
        price: 1.99,
        image_url: 'https://images.unsplash.com/photo-1543218024-57a70143c369?q=80&w=500',
        description: 'Organic fair-trade bananas.',
        unit: 'kg'
      },
      {
        name: 'Fresh Asparagus',
        price: 4.49,
        image_url: 'https://images.unsplash.com/photo-1515471209610-dae1c92d8777?q=80&w=500',
        description: 'Tender green asparagus.',
        unit: 'bunch'
      },
      {
        name: 'Sweet Corn',
        price: 0.99,
        image_url: 'https://images.unsplash.com/photo-1551754655-cd27e38da46e?q=80&w=500',
        description: 'Fresh sweet corn on the cob.',
        unit: 'piece'
      },
      {
        name: 'Avocados',
        price: 2.49,
        image_url: 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?q=80&w=500',
        description: 'Ripe Hass avocados.',
        unit: 'piece'
      }
    ];
    
    console.log("Attempting to seed", products.length, "products");
    
    // Use supabase insert with auth token
    const { data: insertedData, error: insertError } = await supabase
      .from('products')
      .insert(products)
      .select();
    
    if (insertError) {
      console.error("Failed to seed products:", insertError);
      throw insertError;
    }
    
    console.log('Products seeded successfully:', insertedData?.length || 0, 'products added');
    toast.success(`${insertedData?.length || 0} products seeded successfully`);
  } catch (error) {
    console.error('Error seeding products:', error);
    toast.error('Failed to seed products');
  }
};
