
import React, { useEffect, useState } from 'react';
import { getProducts, seedProducts } from '@/services/api';
import { Product } from '@/components/ProductCard';
import ProductCard from '@/components/ProductCard';
import Navbar from '@/components/Navbar';
import AnimatedBanner from '@/components/AnimatedBanner';
import { Loader2 } from 'lucide-react';
import { toast } from "sonner";

const Index = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const initializeProducts = async () => {
      try {
        // Seed products if none exist
        await seedProducts();
        
        // Then fetch products
        const data = await getProducts();
        setProducts(data);
        if (data.length === 0) {
          toast.error("No products found. Please check your database.");
        }
      } catch (error) {
        console.error('Failed to fetch products:', error);
        toast.error("Failed to load products. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    
    initializeProducts();
  }, []);
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8">
        <AnimatedBanner />
        
        <section className="mb-12">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Fresh from the Farm</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Browse our selection of premium quality vegetables and fruits, ready for your bulk orders.
            </p>
          </div>
          
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-xl text-gray-500">No products available at the moment.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
};

export default Index;
