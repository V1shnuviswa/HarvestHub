
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { getOrderById, getOrders, Order } from '@/services/api';
import { Search, ShoppingCart, Package, Calendar, Sparkles } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import OrderStatusBadge from '@/components/OrderStatusBadge';
import { useToast } from '@/hooks/use-toast';

const TrackOrderPage: React.FC = () => {
  const [orderId, setOrderId] = useState('');
  const [order, setOrder] = useState<Order | null>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const navigate = useNavigate();

  // Load recent orders
  useEffect(() => {
    const loadRecentOrders = async () => {
      try {
        const allOrders = await getOrders();
        // Get the 3 most recent orders
        const recent = allOrders
          .sort((a, b) => new Date(b.orderDate).getTime() - new Date(a.orderDate).getTime())
          .slice(0, 3);
        setRecentOrders(recent);
      } catch (err) {
        console.error('Error loading recent orders:', err);
      }
    };
    
    loadRecentOrders();
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!orderId.trim()) {
      setError('Please enter an order ID');
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      const foundOrder = await getOrderById(orderId);
      
      if (foundOrder) {
        setOrder(foundOrder);
      } else {
        setError('Order not found. Please check your order ID and try again.');
        toast({
          title: "Order Not Found",
          description: "We couldn't find an order with that ID.",
          variant: "destructive",
        });
      }
    } catch (err) {
      console.error('Error searching for order:', err);
      setError('An error occurred while searching for your order. Please try again.');
      toast({
        title: "Error",
        description: "There was a problem searching for your order.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const selectOrder = async (id: string) => {
    setOrderId(id);
    // Auto-search when selecting an order from recent list
    setIsLoading(true);
    try {
      const foundOrder = await getOrderById(id);
      if (foundOrder) {
        setOrder(foundOrder);
      }
    } catch (err) {
      console.error('Error loading selected order:', err);
      toast({
        title: "Error",
        description: "Could not load the selected order.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const calculateTotal = (order: Order) => {
    return order.items.reduce((total, item) => {
      return total + (item.price * item.quantity);
    }, 0);
  };

  const handlePlaceNewOrder = () => {
    navigate('/order');
  };

  return (
    <div className="modern-gradient-bg">
      <Navbar />
      
      <div className="floating-elements">
        <div className="floating-element element-1"></div>
        <div className="floating-element element-2"></div>
        <div className="floating-element element-3"></div>
      </div>
      
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-3 text-center relative">
            <span className="inline-block transform hover:scale-105 transition-transform duration-300">
              Track Your Order
              <Sparkles className="inline-block ml-2 h-8 w-8 text-accent animate-pulse" />
            </span>
          </h1>
          <p className="text-muted-foreground text-center mb-8 max-w-lg mx-auto">
            Enter your order ID below to check the status and details of your delivery.
          </p>
          
          <Card className="glass-card floating-card mb-8">
            <CardHeader className="border-b border-white/10">
              <CardTitle className="text-xl flex items-center">
                <Package className="mr-2 h-5 w-5 text-primary" />
                Enter Order ID
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleSearch} className="search-container flex items-center gap-4">
                <div className="flex-grow">
                  <Input
                    value={orderId}
                    onChange={e => setOrderId(e.target.value)}
                    placeholder="e.g., ORD-123ABC"
                    disabled={isLoading}
                    className="search-input"
                  />
                </div>
                <Button 
                  type="submit" 
                  disabled={isLoading}
                  className="modern-button flex items-center gap-2"
                >
                  {isLoading ? (
                    <div className="h-4 w-4 border-t-2 border-b-2 border-white rounded-full animate-spin"></div>
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                  Track Order
                </Button>
              </form>
              
              {error && (
                <div className="mt-4 text-red-500 text-sm bg-red-50 p-3 rounded-lg border border-red-100 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  {error}
                </div>
              )}
            </CardContent>

            {recentOrders.length > 0 && !order && (
              <CardFooter className="flex-col items-start border-t border-white/10 pt-4">
                <h3 className="text-sm font-medium mb-2 flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-secondary" />
                  Recent Orders:
                </h3>
                <div className="w-full space-y-2">
                  {recentOrders.map(recentOrder => (
                    <Button
                      key={recentOrder.id}
                      variant="outline" 
                      className="w-full justify-start text-left hover:bg-white/50 hover:border-primary/30 transition-all duration-200"
                      onClick={() => selectOrder(recentOrder.id)}
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="font-mono">{recentOrder.id}</span>
                        <OrderStatusBadge status={recentOrder.status} />
                      </div>
                    </Button>
                  ))}
                </div>
              </CardFooter>
            )}
          </Card>
          
          {order && (
            <Card className="glass-card overflow-hidden transition-all duration-500 animate-fade-in">
              <CardHeader className="border-b border-white/10">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl">{order.id}</CardTitle>
                    <div className="text-muted-foreground mt-1 flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>{formatDate(order.orderDate)}</span>
                    </div>
                  </div>
                  <OrderStatusBadge status={order.status} />
                </div>
              </CardHeader>
              
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Customer Info */}
                  <div className="bg-white/40 p-4 rounded-lg">
                    <h3 className="font-semibold text-lg mb-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      Customer Information
                    </h3>
                    <div className="space-y-1 text-sm">
                      <p className="font-medium">{order.customerName}</p>
                      <p>{order.contactInfo}</p>
                    </div>
                  </div>
                  
                  {/* Delivery Address */}
                  <div className="bg-white/40 p-4 rounded-lg">
                    <h3 className="font-semibold text-lg mb-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      Delivery Address
                    </h3>
                    <p className="text-sm whitespace-pre-wrap">{order.deliveryAddress}</p>
                  </div>
                </div>
                
                <Separator className="my-6 bg-white/20" />
                
                {/* Order Items */}
                <h3 className="font-semibold text-lg mb-4 flex items-center">
                  <ShoppingCart className="mr-2 h-5 w-5 text-accent" />
                  Order Items
                </h3>
                <div className="space-y-4 bg-white/30 rounded-lg p-4">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-center pb-2 border-b border-white/30">
                      <div className="flex items-center gap-3">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <ShoppingCart className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-muted-foreground">
                            ${item.price.toFixed(2)} per {item.unit || 'kg'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{item.quantity} {item.unit || 'kg'}</p>
                        <p className="text-sm font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Order Total */}
                <div className="mt-6 flex justify-end">
                  <div className="bg-primary/10 p-4 rounded-lg border border-primary/20">
                    <div className="flex justify-between text-sm mb-2">
                      <span>Subtotal:</span>
                      <span className="font-medium">${calculateTotal(order).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total:</span>
                      <span>${calculateTotal(order).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-between border-t border-white/10 pt-6">
                <Button 
                  variant="outline" 
                  onClick={() => setOrder(null)}
                  className="hover:bg-white/50"
                >
                  Back
                </Button>
                <Button 
                  onClick={handlePlaceNewOrder} 
                  className="modern-button flex items-center gap-2"
                >
                  <Package className="h-4 w-4" />
                  Place New Order
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default TrackOrderPage;
