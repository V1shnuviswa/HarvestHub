
export interface Product {
  id: number;
  name: string;
  price: number;
  imageUrl: string;
  description?: string;
  unit?: string;
}

export interface Order {
  id: string;
  customerName: string;
  contactInfo: string;
  deliveryAddress: string;
  items: OrderItem[];
  status: 'pending' | 'in-progress' | 'delivered';
  orderDate: string;
}

export interface OrderItem {
  productId: number;
  name: string;
  quantity: number;
  price: number;
  unit?: string;
}
